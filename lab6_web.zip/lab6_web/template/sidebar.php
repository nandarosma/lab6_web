<div class="sidebar">
<!-- row 1 -->
<div class="row">
<div class="col-md">
<div class="card text-bg-primary mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">Primary card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>
</div>
<!-- row 2 -->
<div class="row">
<div class="col-md">
<div class="card text-bg-warning mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">warning card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>

</div>
<div class="col-md">
<div class="card text-bg-warning mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">warning card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>
</div>
<!-- row 3 -->
<div class="row">
<div class="col-md">
<div class="card text-bg-success mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">success card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>
<div class="col-md">
<div class="card text-bg-success mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">success card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>
<div class="col-lg">
<div class="card text-bg-success mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">success card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>
</div>
<!-- row 4 -->
<div class="row">
<div class="col-md-5 offset-md-1">
<div class="card text-bg-secondary mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">secondary card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>

<div class="col-md-5">
<div class="card text-bg-secondary mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">secondary card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>
</div>
<!-- row 5 -->
<div class="row">
<div class="col-lg-2">
<div class="card text-bg-danger mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">danger card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>
<div class="col-lg-2">
<div class="card text-bg-danger mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">danger card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>
<div class="col-lg-2">
<div class="card text-bg-danger mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">danger card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>
<div class="col-lg-2">
<div class="card text-bg-danger mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">danger card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>

<div class="col-lg-2">
<div class="card text-bg-danger mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">danger card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>
<div class="col-lg-2 mb-5 pb-5">
<div class="card text-bg-danger mb-3">
<div class="card-header">Header</div>
<div class="card-body">
<h5 class="card-title">danger card title</h5>
<p class="card-text">Some quick example text to build
on the card title and make up the bulk of the card's content.</p>
</div>
</div>
</div>
</div>
</div>